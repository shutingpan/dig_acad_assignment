const express = require("express");
const { getAllUsers, createGroup, createUser, updateEmail, updatePassword, editUser } = require("../controllers/adminController");
const { loginUser, logoutUser, isAuthenticatedUser, getProfile, authorizedGrps, isAdmin, getApps } = require("../controllers/authController");
const router = express.Router();

// Check admin status
router.route("/isAdmin").get(isAuthenticatedUser, isAdmin);

// Admin
router.route("/ums").get(isAuthenticatedUser, authorizedGrps("admin"), getAllUsers);
router.route("/ums/createGroup").post(isAuthenticatedUser, authorizedGrps("admin"), createGroup);
router.route("/ums/createUser").post(isAuthenticatedUser, authorizedGrps("admin"), createUser);
router.route("/ums/editUser").post(isAuthenticatedUser, authorizedGrps("admin"), editUser);

// Individual user
router.route("/login").post(loginUser, isAuthenticatedUser);
router.route("/logout").post(isAuthenticatedUser, logoutUser);
router.route("/profile").get(isAuthenticatedUser, getProfile);
router.route("/profile/updateEmail").post(isAuthenticatedUser, updateEmail);
router.route("/profile/updatePassword").post(isAuthenticatedUser, updatePassword);

// Placeholder route for main menu - app list
router.route("/tms").get(isAuthenticatedUser, getApps);

module.exports = router;
