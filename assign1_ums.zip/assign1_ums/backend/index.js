// Import modules
const dotenv = require("dotenv");
const express = require("express");
// const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const bcryptJS = require("bcryptjs"); //password hashing
const jwt = require("jsonwebtoken"); // token-based authentication
const cookieParser = require("cookie-parser"); //parse cookies
const cors = require("cors"); // cross origin resource sharing
const app = express();
const port = 3000;

// Set up environment variables
dotenv.config({ path: "./config/config.env" });

app.use(cookieParser());
// app.use(cors());
app.use(
  cors({
    origin: "http://localhost:5173", // Frontend
    credentials: true // Allow credentials to be sent
  })
);

// Inititalize the app and add middleware (before routes)
// app.set("view engine", "pug"); // Setup the pug
app.use(bodyParser.urlencoded({ extended: true })); // Setup the body parser to handle form submits
app.use(bodyParser.json());
// app.use(session({ secret: "super-secret" })); // Session setup

// Import all routes
const users = require("./routes/users");
app.use("/", users);

/** Handle login display and form submit */
// app.get("/login", (req, res) => {
//   if (req.session.isLoggedIn === true) {
//     res.json({ message: "Hello from NodeJS backend" });
//     return res.redirect("/");
//   }
//   res.render("login", { error: false });
// });

/** Simulated bank functionality */
// app.get("/", (req, res) => {
//   res.render("index", { isLoggedIn: req.session.isLoggedIn });
// });

// app.get("/tms", (req, res) => {
//   if (req.session.isLoggedIn === true) {
//     res.send("App List shown.");
//   } else {
//     res.redirect("/login?redirect_url=/tms");
//   }
// });

//     // Authenticate the user
//     // req.session.isLoggedIn = true;
//     // req.session.username = username;

// app.get("/ums", (req, res) => {
//   if (req.session.isLoggedIn === true) {
//     res.send("Admin manages users here (from node).");
//   } else {
//     // res.redirect("/login?redirect_url=/ums");
//     res.send("UMS");
//   }
// });

/** App listening on port */
app.listen(port, () => {
  console.log(`TMS listening at http://localhost:${port}`);
});
