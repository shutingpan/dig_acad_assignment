<script lang="ts">
  import { goto } from '$app/navigation';
  import { page } from '$app/stores';
  import Navbar from "$lib/components/Navbar.svelte";
  import { onMount } from "svelte";  
  // import type { LayoutData } from './$types';
  // export let data: LayoutData;

  // Do not display navbar in login page
  let displayNavbar = false;
  $: displayNavbar = ($page.url.pathname !== '/login');
  onMount(() => {
      if ($page.url.pathname === '/') {
          goto('/login');
      }
  });
</script>

{#if displayNavbar}
  <Navbar />
{/if}
      
<!-- Dynamic: shows +page.svelte in same lvl and inner folders  -->
<div class="container">
  <slot />
</div>

<style>
  .container {
        margin: 10px;
        min-height: 100vh;
        padding: 20px;
        background-color: #ffffff;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
</style>

