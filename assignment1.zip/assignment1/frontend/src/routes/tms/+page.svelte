<script>
  import { goto } from "$app/navigation";
  import axios from "axios";
  import { onMount } from "svelte";

    let apps = [
        {
            acronym: 'XXXXX',
            rnumber: 'XXXXX',
            startDate: 'XXXXX',
            endDate: 'XXXXX',
            taskCreate: 'XXX',
            taskOpen: 'XXX',
            taskToDo: 'XXXX',
            taskDoing: 'XXX',
            taskDone: 'XXX',
            description: 'XXXXXXXXXX',
        }
    ];

    onMount(async () => {
        try {
            // Get tms information
            const response = await axios.get('http://localhost:3000/tms', {
            withCredentials: true
            });

            if (response.data.success) {
                console.log("This will be my app list.");
            } else {
                console.log('Smth went wrong.');
            }
        } catch (err) {
            if (err.response && err.response.status === 401) {
                goto('/login'); // Unauthorized 
            } else {
                console.error("An error occurred: ", err);
            }
        }
  });

</script>

    <div class="header">
        <h1>App Dashboard</h1>
        <button class="create-btn">Create App</button>
    </div>
    <table class="app-table">
        <thead>
            <tr>
                <th>Acronym</th>
                <th>Rnumber</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Task Create</th>
                <th>Task Open</th>
                <th>Task To Do</th>
                <th>Task Doing</th>
                <th>Task Done</th>
                <th>Description</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            {#each apps as app}
                <tr>
                    <td>{app.acronym}</td>
                    <td>{app.rnumber}</td>
                    <td>{app.startDate}</td>
                    <td>{app.endDate}</td>
                    <td>{app.taskCreate}</td>
                    <td>{app.taskOpen}</td>
                    <td>{app.taskToDo}</td>
                    <td>{app.taskDoing}</td>
                    <td>{app.taskDone}</td>
                    <td>{app.description}</td>
                    <td>
                        <button class="open-btn">Open App</button>
                    </td>
                </tr>
            {/each}
        </tbody>
    </table>

<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .header h1 {
        font-size: 24px;
    }

    .create-btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .create-btn:hover {
        background-color: #45a049;
    }

    .app-table {
        width: 100%;
        border-collapse: collapse;
    }

    .app-table th, .app-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }

    .app-table th {
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
    }

    .app-table tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .app-table tr:hover {
        background-color: #ddd;
    }

    .open-btn {
        background-color: #333;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .open-btn:hover {
        background-color: #555;
    }
</style>
