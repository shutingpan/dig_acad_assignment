<script>
  import axios from 'axios';
  import MultiSelect from "svelte-multiselect";
  import {page} from '$app/stores';

  // For displaying users
  let { usersData, groupList, groupListPerUser } = $page.data;

  // For creating user
  let username = '', password = '', email = '', isActive = true, selectedGrps = [];
  let usrMsg = '', pwdMsg = '', emailMsg ='';
  let createUserMsg = '', isUserCreated = false;   

  // For creating group
  let newGroup = '', groupErrorMsg ='', isGroupValid = false;

  // For editing user credentials
  let editingIdx = null;
  let tempData = {}, origGrpSelectn = [];
  let isSaved = false, savedPwdMsg = '', savedEmailMsg = '', savedMsg="";

  async function createGroup() {   
        try {
            const response = await axios.post('http://localhost:3000/ums/createGroup', {
                newGroup : newGroup
            }, {
                headers: { 
                    'Content-Type': 'application/json'
                },
                withCredentials: true // for including cookies
            });

            if (response.data.success) {
                // Notification
                groupErrorMsg = response.data.message;
                isGroupValid = response.data.success;
                setTimeout(()=>{groupErrorMsg=''}, 3000);
                // Update group list 
                groupList = [newGroup, ...groupList];
                // Reset input field
                newGroup = '';
            } else {
                // Show error messages
                groupErrorMsg = response.data.message;
                isGroupValid = response.data.success;
                setTimeout(()=>{groupErrorMsg=''}, 3000);
            }
        } catch (err) {
            console.error('Error occurred.');
            groupErrorMsg = "An error occurred when creating group.";
        }
  }

  async function createNewUser() {
    cancelEdit();
    const newUser = {
        username,
        password,
        email,
        isActive,
        selectedGrps
    };

    try {
      const response = await axios.post('http://localhost:3000/ums/createUser',{
            newUser : newUser
        }, {
            headers: { 
                'Content-Type': 'application/json'
            }, 
            withCredentials: true // include cookies
        });

        if (response.data.success) {
            // Insert row for new user
            usersData = [response.data.createdUser, ...usersData];
            // Update selected grps for new user
            groupListPerUser[username] = selectedGrps;
            // Notification
            createUserMsg = response.data.message;
            isUserCreated = response.data.success;
            setTimeout(()=>{createUserMsg=''}, 3000);
            // Reset error msgs
            usrMsg = ''; pwdMsg = ''; emailMsg = '';
            // Reset form inputs
            username =''; password='';email=''; isActive=true; selectedGrps=[];
       } else {
            // Show error msgs 
            usrMsg = response.data.usrMsg;
            pwdMsg = response.data.pwdMsg;
            emailMsg = response.data.emailMsg;
            createUserMsg = response.data.message;
            isUserCreated = response.data.success;
            setTimeout(()=>{createUserMsg=''}, 3000);

       }
    } catch (error) {
      console.error('Error creating user:', error);
    }
  }

  // Edit row mode
  function editRow(index) {
    // Exit any pre-existing edit mode
    if (editingIdx !== null) {
        console.log("Unable to edit as another row in edit mode.", tempData);
        cancelEdit();
    }

    isSaved = false; // disable any existing notif
    editingIdx = index;

    // Store orig assigned grps as deep copy
    origGrpSelectn = [...(groupListPerUser[usersData[index].username] || [] )];
    console.log("Storing orig selection: ", origGrpSelectn);
    // temporary store for updates to user information 
    tempData = {...usersData[index]};
    tempData.selectedGrps = [...groupListPerUser[tempData.username] || []];
    console.log("Now editing at row ", index, " : ", tempData);
  }

  // Cancel edits without saving
  function cancelEdit() {
    // Revert changes to groups (if any)
    if (editingIdx !== null && tempData.username) {
        console.log("Restore orig selection:", origGrpSelectn);
        groupListPerUser[tempData.username] = [...origGrpSelectn];
    }
    editingIdx = null;
    tempData = {};
    // origGrpSelectn = [];
    console.log('Cancelling edit.');
  }

  // Save row, send update data and exit edit mode.
  async function saveRow(index) {
    try {
        const response = await axios.post('http://localhost:3000/ums/editUser', {
        tempData 
        }, {
        headers: { 'Content-Type': 'application/json' },
        withCredentials: true // include cookies
        });
        if (response.data.success) {
            // Update changed credentials and assigned groups
            usersData[index] = { ...response.data.updatedUser};
            groupListPerUser[tempData.username] = tempData.selectedGrps;
            // Reset error msgs & editing mode
            editingIdx = null;
            savedEmailMsg = '';
            savedPwdMsg = '';
            isSaved = response.data.success;
            savedMsg = response.data.message;
            setTimeout(() => { isSaved = false;}, 3000);
        } else {
            savedEmailMsg = response.data.emailErrMsg;
            savedPwdMsg = response.data.pwdErrMsg;
            isSaved = response.data.success;
            savedMsg = response.data.message;
        }
    } catch (error) {
        console.error("An error occurred while saving user.");
    }
  }

</script>

{#if isSaved}
    <span class="errorMsg notification" style="color: {isSaved? 'green': 'red'}; background-color: {isSaved? 'rgb(171, 230, 167)':'rgb(255, 193, 193)'}">{savedMsg}</span>
{/if}

<h1>User Management</h1>

<!-- Create Group -->
<span>New Group: </span>
<input type="text" placeholder="Enter a new group" bind:value={newGroup} on:focus={()=> groupErrorMsg=""} required> 
<button on:click|preventDefault={createGroup}>Add Group</button>
<!-- Notification -->
{#if groupErrorMsg}
    <span class="errorMsg" style="color: {isGroupValid? 'green': 'red'}; background-color: {isGroupValid? 'rgb(171, 230, 167)':'rgb(255, 193, 193)'}" >{groupErrorMsg}</span>
{/if}

<!-- Notification (Create user) -->
{#if createUserMsg}
    <span class="errorMsg" style="color: {isUserCreated? 'green': 'red'}; background-color: {isUserCreated? 'rgb(171, 230, 167)':'rgb(255, 193, 193)'}">{createUserMsg}</span>
{/if}
<!-- Display users information -->
<table class="table">
    <thead>
        <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Email</th>
            <th>Group</th>
            <th>Active</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <!-- Create New User -->
        <tr>
            <!-- Create username -->
            <td>
                <input type="text" placeholder="Enter username" bind:value={username} 
                on:focus={()=> {usrMsg=""; createUserMsg=""}}><br>
                {#if usrMsg}
                    <span class="errorMsg">{usrMsg}</span>
                {/if}
            </td>
            <!-- Create password -->
            <td>
                <input type="password" placeholder="Enter password" bind:value={password}  on:focus={()=> {pwdMsg=""; createUserMsg=""}}><br>
                {#if pwdMsg}
                <span class="errorMsg">{pwdMsg}</span>
                {/if}
            </td>
            <!-- Create email -->
            <td>
                <input type="email" placeholder="Enter email" bind:value={email} on:focus={()=>{emailMsg=""; createUserMsg=""}}><br>
                {#if emailMsg}
                    <span class="errorMsg">{emailMsg}</span>
                {/if}
            </td>

            <!-- Newly assigned groups -->
            <td>
                <MultiSelect
                options={groupList}
                placeholder="No groups assigned" 
                maxSelect={groupList.length - 1}
                bind:selected={selectedGrps}
                ></MultiSelect>
            </td>
            <td><input type="checkbox" bind:checked={isActive}></td>
            <td><button on:click|preventDefault={createNewUser}>Create</button></td>

        </tr>

        {#each usersData as row, index}
            <tr>
                {#if editingIdx === index}
                    <!-- Editable row -->
                    <!-- Username (RO) -->
                    <td>{tempData.username}</td>
                    <!-- Password -->
                    <td><input type="password" bind:value={tempData.password}>
                        {#if savedPwdMsg}
                            <span class="errorMsg">{savedPwdMsg}</span>
                        {/if}
                    </td>
                    <!-- Email -->
                    <td><input type="email" bind:value={tempData.email}>
                        {#if savedEmailMsg}
                            <span class="errorMsg">{savedEmailMsg}</span>
                        {/if}
                    </td>
                    <!-- Group -->
                    <td>
                        <MultiSelect
                        options={groupList}
                        maxSelect={groupList.length - 1}
                        bind:selected={tempData.selectedGrps}
                        placeholder="No groups assigned"
                        ></MultiSelect>
                    </td>
                    <!-- Active Status -->
                    <td>
                        <input type="checkbox" bind:checked={tempData.isActive}>
                    </td>
                    <!-- Action-->
                    <td>
                    <button on:click={() => saveRow(index)}>Save</button>
                    <button on:click={cancelEdit}>Cancel</button>
                    </td>
                {:else}
                    <!-- Read-only row -->
                    <!-- Username -->
                    <td>{row.username}</td>
                    <!-- Password -->
                    <td>**********</td>
                    <!-- Email -->
                    <td>{row.email}</td>
                    <!-- Group -->
                    <td>
                        <MultiSelect
                        options={groupList}
                        maxSelect={groupList.length - 1}
                        bind:selected={groupListPerUser[row.username]}
                        placeholder="No groups assigned"
                        disabled></MultiSelect>
                    </td>
                    <!-- Active Status -->
                    <td>                    
                        <input type="checkbox" bind:checked={row.isActive} disabled>
                    </td>
                    <!-- Action-->
                    <td><button on:click={() => editRow(index)}>Edit</button></td>
                {/if}
            </tr>
        {/each}
    </tbody>
</table>            

<style>
    h1 {
        font-size: 24px;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    .table th, .table td {
        border: 1px solid #dee2e6;
        padding: 12px;
        text-align: left;
        /* vertical-align: middle; */
        
    }
    .table th {
        background-color: #f8f9fa;
        color: #212529;
        font-weight: bold;
    }
    .table tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    .table tbody tr:hover {
        background-color: #e9ecef;
    }
    button {
        margin: 3px;
    }

    .errorMsg {
        display: block;
        background-color: rgb(255, 193, 193);
        color: red;
        font-size: small;
        min-height: 1rem;
        margin: 5px 0px;
        padding: 5px;
        border-radius: 3px;
    }

    .notification {
        position: fixed;
        top: 20px;
        right: 50%; 
        padding: 10px;
        border-radius: 3px;
        z-index: 1000; /* stay on top of other elements */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
</style>
